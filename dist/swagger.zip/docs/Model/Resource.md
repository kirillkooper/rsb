# Resource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** |  | [optional] 
**file** | [**\Swagger\Client\Model\File**](File.md) |  | [optional] 
**filename** | **string** |  | [optional] 
**input_stream** | [**\Swagger\Client\Model\InputStream**](InputStream.md) |  | [optional] 
**open** | **bool** |  | [optional] 
**readable** | **bool** |  | [optional] 
**uri** | [**\Swagger\Client\Model\URI**](URI.md) |  | [optional] 
**url** | [**\Swagger\Client\Model\URL**](URL.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


