# CreditBrokerApiRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_xml** | **string** |  | [optional] 
**is_signed** | **bool** |  | [optional] 
**sig_data** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


