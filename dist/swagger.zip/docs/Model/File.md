# File

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**absolute** | **bool** |  | [optional] 
**absolute_file** | [**\Swagger\Client\Model\File**](File.md) |  | [optional] 
**absolute_path** | **string** |  | [optional] 
**canonical_file** | [**\Swagger\Client\Model\File**](File.md) |  | [optional] 
**canonical_path** | **string** |  | [optional] 
**directory** | **bool** |  | [optional] 
**executable** | **bool** |  | [optional] 
**file** | **bool** |  | [optional] 
**free_space** | **int** |  | [optional] 
**hidden** | **bool** |  | [optional] 
**last_modified** | **int** |  | [optional] 
**name** | **string** |  | [optional] 
**parent** | **string** |  | [optional] 
**parent_file** | [**\Swagger\Client\Model\File**](File.md) |  | [optional] 
**path** | **string** |  | [optional] 
**readable** | **bool** |  | [optional] 
**total_space** | **int** |  | [optional] 
**usable_space** | **int** |  | [optional] 
**writable** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


