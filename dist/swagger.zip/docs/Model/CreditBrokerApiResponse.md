# CreditBrokerApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**application_id** | **string** |  | [optional] 
**error** | **string** |  | [optional] 
**error_description** | **string** |  | [optional] 
**loan_id** | **string** |  | [optional] 
**status** | **string** |  | [optional] 
**status_comment** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


