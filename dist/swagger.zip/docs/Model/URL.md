# URL

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authority** | **string** |  | [optional] 
**content** | **object** |  | [optional] 
**default_port** | **int** |  | [optional] 
**deserialized_fields** | [**\Swagger\Client\Model\URLStreamHandler**](URLStreamHandler.md) |  | [optional] 
**file** | **string** |  | [optional] 
**host** | **string** |  | [optional] 
**path** | **string** |  | [optional] 
**port** | **int** |  | [optional] 
**protocol** | **string** |  | [optional] 
**query** | **string** |  | [optional] 
**ref** | **string** |  | [optional] 
**serialized_hash_code** | **int** |  | [optional] 
**user_info** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


