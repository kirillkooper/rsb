# UploadDocResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**description** | **string** |  | [optional] 
**ext_id** | **string** |  | [optional] 
**file_uid** | **string** |  | [optional] 
**name** | **string** |  | [optional] 
**size** | **int** |  | [optional] 
**type** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


