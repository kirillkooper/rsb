# URI

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**absolute** | **bool** |  | [optional] 
**authority** | **string** |  | [optional] 
**fragment** | **string** |  | [optional] 
**host** | **string** |  | [optional] 
**opaque** | **bool** |  | [optional] 
**path** | **string** |  | [optional] 
**port** | **int** |  | [optional] 
**query** | **string** |  | [optional] 
**raw_authority** | **string** |  | [optional] 
**raw_fragment** | **string** |  | [optional] 
**raw_path** | **string** |  | [optional] 
**raw_query** | **string** |  | [optional] 
**raw_scheme_specific_part** | **string** |  | [optional] 
**raw_user_info** | **string** |  | [optional] 
**scheme** | **string** |  | [optional] 
**scheme_specific_part** | **string** |  | [optional] 
**user_info** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


