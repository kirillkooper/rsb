# Swagger\Client\XsdSchemesControllerApi

All URIs are relative to *https://10.7.27.24:2733/rest/api/v2/credit/broker*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCreateApplicationLoanRequestMsgUsingGET**](XsdSchemesControllerApi.md#getCreateApplicationLoanRequestMsgUsingGET) | **GET** /v2/xsdSchema/CreateApplicationLoanRequestMsg | Актуальная xsd схема для создания полной заявки в бискивите. Файл: CreateApplicationLoan_v3_req_pro.xsd
[**getCreateApplicationShortReqProUsingGET**](XsdSchemesControllerApi.md#getCreateApplicationShortReqProUsingGET) | **GET** /v2/xsdSchema/CreateApplicationShortRequestMsg | Актуальная xsd схема для создания короткой заявки в бискивите. Файл: CreateApplicationShort_req_pro.xsd
[**getSchemaApplicationLoanRequestUsingGET**](XsdSchemesControllerApi.md#getSchemaApplicationLoanRequestUsingGET) | **GET** /v2/xsdSchema/ApplicationLoanRequest | Актуальная xsd схема для создания заявки.


# **getCreateApplicationLoanRequestMsgUsingGET**
> string getCreateApplicationLoanRequestMsgUsingGET()

Актуальная xsd схема для создания полной заявки в бискивите. Файл: CreateApplicationLoan_v3_req_pro.xsd

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');

$apiInstance = new Swagger\Client\Api\XsdSchemesControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getCreateApplicationLoanRequestMsgUsingGET();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling XsdSchemesControllerApi->getCreateApplicationLoanRequestMsgUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getCreateApplicationShortReqProUsingGET**
> string getCreateApplicationShortReqProUsingGET()

Актуальная xsd схема для создания короткой заявки в бискивите. Файл: CreateApplicationShort_req_pro.xsd

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');

$apiInstance = new Swagger\Client\Api\XsdSchemesControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getCreateApplicationShortReqProUsingGET();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling XsdSchemesControllerApi->getCreateApplicationShortReqProUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getSchemaApplicationLoanRequestUsingGET**
> string getSchemaApplicationLoanRequestUsingGET()

Актуальная xsd схема для создания заявки.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');

$apiInstance = new Swagger\Client\Api\XsdSchemesControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getSchemaApplicationLoanRequestUsingGET();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling XsdSchemesControllerApi->getSchemaApplicationLoanRequestUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

