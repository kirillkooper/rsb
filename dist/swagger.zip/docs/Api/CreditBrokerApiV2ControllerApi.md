# Swagger\Client\CreditBrokerApiV2ControllerApi

All URIs are relative to *https://10.7.27.24:2733/rest/api/v2/credit/broker*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createApplicationUsingPOST**](CreditBrokerApiV2ControllerApi.md#createApplicationUsingPOST) | **POST** /application | Создание кредитной заявки в шлюзе банка
[**finishUploadDocumentsUsingGET**](CreditBrokerApiV2ControllerApi.md#finishUploadDocumentsUsingGET) | **GET** /application/finish | Завршение процесса загрузки документов и отправка кредитной заявки в кредитный процессор
[**getApplicationUsingGET**](CreditBrokerApiV2ControllerApi.md#getApplicationUsingGET) | **GET** /application | Получение информации о кредитной заявке
[**healzUsingGET**](CreditBrokerApiV2ControllerApi.md#healzUsingGET) | **GET** /application/healz | Метод, возвращающий \&quot;ОК\&quot;
[**signatureUsingPOST**](CreditBrokerApiV2ControllerApi.md#signatureUsingPOST) | **POST** /application/signature | Подписание заявки ЭП
[**statusUsingGET**](CreditBrokerApiV2ControllerApi.md#statusUsingGET) | **GET** /application/status | Получение текущего статуса заявки.


# **createApplicationUsingPOST**
> \Swagger\Client\Model\CreditBrokerApiResponse createApplicationUsingPOST($application, $name)

Создание кредитной заявки в шлюзе банка

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application = new \Swagger\Client\Model\CreditBrokerApiRequest(); // \Swagger\Client\Model\CreditBrokerApiRequest | application
$name = "name_example"; // string | 

try {
    $result = $apiInstance->createApplicationUsingPOST($application, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->createApplicationUsingPOST: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application** | [**\Swagger\Client\Model\CreditBrokerApiRequest**](../Model/CreditBrokerApiRequest.md)| application |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\CreditBrokerApiResponse**](../Model/CreditBrokerApiResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **finishUploadDocumentsUsingGET**
> \Swagger\Client\Model\CreditBrokerApiResponse finishUploadDocumentsUsingGET($application_id, $name)

Завршение процесса загрузки документов и отправка кредитной заявки в кредитный процессор

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$name = "name_example"; // string | 

try {
    $result = $apiInstance->finishUploadDocumentsUsingGET($application_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->finishUploadDocumentsUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\CreditBrokerApiResponse**](../Model/CreditBrokerApiResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getApplicationUsingGET**
> \Swagger\Client\Model\CreditBrokerApiResponse getApplicationUsingGET($application_id, $name)

Получение информации о кредитной заявке

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$application_id = "application_id_example"; // string | applicationId
$name = "name_example"; // string | 

try {
    $result = $apiInstance->getApplicationUsingGET($application_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->getApplicationUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\CreditBrokerApiResponse**](../Model/CreditBrokerApiResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **healzUsingGET**
> string healzUsingGET()

Метод, возвращающий \"ОК\"

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);

try {
    $result = $apiInstance->healzUsingGET();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->healzUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **signatureUsingPOST**
> string signatureUsingPOST($application, $name)

Подписание заявки ЭП

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client()
);
$application = "application_example"; // string | application
$name = "name_example"; // string | 

try {
    $result = $apiInstance->signatureUsingPOST($application, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->signatureUsingPOST: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application** | **string**| application |
 **name** | **string**|  | [optional]

### Return type

**string**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **statusUsingGET**
> \Swagger\Client\Model\CreditBrokerApiResponse statusUsingGET($application_id, $name)

Получение текущего статуса заявки.

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\CreditBrokerApiV2ControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$name = "name_example"; // string | 

try {
    $result = $apiInstance->statusUsingGET($application_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling CreditBrokerApiV2ControllerApi->statusUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\CreditBrokerApiResponse**](../Model/CreditBrokerApiResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

