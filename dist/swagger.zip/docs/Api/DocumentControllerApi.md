# Swagger\Client\DocumentControllerApi

All URIs are relative to *https://10.7.27.24:2733/rest/api/v2/credit/broker*

Method | HTTP request | Description
------------- | ------------- | -------------
[**attachDocumentUsingPOST**](DocumentControllerApi.md#attachDocumentUsingPOST) | **POST** /application/document | Добавить файл к кредитной заявке
[**deleteDocumentUsingDELETE**](DocumentControllerApi.md#deleteDocumentUsingDELETE) | **DELETE** /application/document/{id} | Удалить документ из заявки
[**getDocumentTypesUsingGET**](DocumentControllerApi.md#getDocumentTypesUsingGET) | **GET** /application/document/types | Получить все доступные типы документов
[**getFileUsingGET**](DocumentControllerApi.md#getFileUsingGET) | **GET** /application/document/{id} | Скачать файл, прикрепленный к заявке
[**getListDocumentsUsingGET**](DocumentControllerApi.md#getListDocumentsUsingGET) | **GET** /application/document | Список прикрепленных файлов
[**submitUsingPOST**](DocumentControllerApi.md#submitUsingPOST) | **POST** /application/documents | Прикрепить  файлы к кредитной заявке через multipart/form-data запрос


# **attachDocumentUsingPOST**
> \Swagger\Client\Model\UploadDocResponse attachDocumentUsingPOST($application_id, $request, $name)

Добавить файл к кредитной заявке

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$request = new \Swagger\Client\Model\UploadDocRequest(); // \Swagger\Client\Model\UploadDocRequest | request
$name = "name_example"; // string | 

try {
    $result = $apiInstance->attachDocumentUsingPOST($application_id, $request, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->attachDocumentUsingPOST: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **request** | [**\Swagger\Client\Model\UploadDocRequest**](../Model/UploadDocRequest.md)| request |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\UploadDocResponse**](../Model/UploadDocResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **deleteDocumentUsingDELETE**
> bool deleteDocumentUsingDELETE($application_id, $id, $name)

Удалить документ из заявки

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$id = "id_example"; // string | id
$name = "name_example"; // string | 

try {
    $result = $apiInstance->deleteDocumentUsingDELETE($application_id, $id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->deleteDocumentUsingDELETE: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **id** | [**string**](../Model/.md)| id |
 **name** | **string**|  | [optional]

### Return type

**bool**

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getDocumentTypesUsingGET**
> \Swagger\Client\Model\DocumentTypesResponse[] getDocumentTypesUsingGET()

Получить все доступные типы документов

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);

try {
    $result = $apiInstance->getDocumentTypesUsingGET();
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->getDocumentTypesUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**\Swagger\Client\Model\DocumentTypesResponse[]**](../Model/DocumentTypesResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getFileUsingGET**
> string getFileUsingGET($application_id, $id, $name)

Скачать файл, прикрепленный к заявке

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$id = "id_example"; // string | id
$name = "name_example"; // string | 

try {
    $result = $apiInstance->getFileUsingGET($application_id, $id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->getFileUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **id** | [**string**](../Model/.md)| id |
 **name** | **string**|  | [optional]

### Return type

**string**

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **getListDocumentsUsingGET**
> \Swagger\Client\Model\UploadDocResponse[] getListDocumentsUsingGET($application_id, $name)

Список прикрепленных файлов

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = "application_id_example"; // string | applicationId
$name = "name_example"; // string | 

try {
    $result = $apiInstance->getListDocumentsUsingGET($application_id, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->getListDocumentsUsingGET: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | **string**| applicationId |
 **name** | **string**|  | [optional]

### Return type

[**\Swagger\Client\Model\UploadDocResponse[]**](../Model/UploadDocResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

# **submitUsingPOST**
> \Swagger\Client\Model\UploadDocResponse submitUsingPOST($application_id, $ext_uid, $file, $is_signed, $type, $name)

Прикрепить  файлы к кредитной заявке через multipart/form-data запрос

### Example
```php
<?php
require_once(__DIR__ . '/vendor/autoload.php');

// Configure API key authorization: RSHB_BEARER_AUTH
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKey('Authorization', 'YOUR_API_KEY');
// Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
// $config = Swagger\Client\Configuration::getDefaultConfiguration()->setApiKeyPrefix('Authorization', 'Bearer');
// Configure OAuth2 access token for authorization: RSHB_OAUTH2
$config = Swagger\Client\Configuration::getDefaultConfiguration()->setAccessToken('YOUR_ACCESS_TOKEN');

$apiInstance = new Swagger\Client\Api\DocumentControllerApi(
    // If you want use custom http client, pass your client which implements `GuzzleHttp\ClientInterface`.
    // This is optional, `GuzzleHttp\Client` will be used as default.
    new GuzzleHttp\Client(),
    $config
);
$application_id = new \stdClass; // object | applicationId
$ext_uid = new \stdClass; // object | extUid
$file = "/path/to/file.txt"; // \SplFileObject | file
$is_signed = new \stdClass; // object | isSigned
$type = new \stdClass; // object | type
$name = new \stdClass; // object | 

try {
    $result = $apiInstance->submitUsingPOST($application_id, $ext_uid, $file, $is_signed, $type, $name);
    print_r($result);
} catch (Exception $e) {
    echo 'Exception when calling DocumentControllerApi->submitUsingPOST: ', $e->getMessage(), PHP_EOL;
}
?>
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **application_id** | [**object**](../Model/.md)| applicationId |
 **ext_uid** | [**object**](../Model/.md)| extUid |
 **file** | **\SplFileObject**| file |
 **is_signed** | [**object**](../Model/.md)| isSigned |
 **type** | [**object**](../Model/.md)| type |
 **name** | [**object**](../Model/.md)|  | [optional]

### Return type

[**\Swagger\Client\Model\UploadDocResponse**](../Model/UploadDocResponse.md)

### Authorization

[RSHB_BEARER_AUTH](../../README.md#RSHB_BEARER_AUTH), [RSHB_OAUTH2](../../README.md#RSHB_OAUTH2)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: */*

[[Back to top]](#) [[Back to API list]](../../README.md#documentation-for-api-endpoints) [[Back to Model list]](../../README.md#documentation-for-models) [[Back to README]](../../README.md)

